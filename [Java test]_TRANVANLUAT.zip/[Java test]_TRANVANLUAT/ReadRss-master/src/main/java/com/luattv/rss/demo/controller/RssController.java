package com.luattv.rss.demo.controller;

import com.luattv.rss.demo.common.Constants;
import com.luattv.rss.demo.service.RssParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by luattv on 14/06/2016.
 */
@Controller
public class RssController {

    @Autowired
    private RssParser rssParser;

    @RequestMapping(value = "/rss", method = RequestMethod.GET)
    public ModelAndView createRss() {
        rssParser.readRss(Constants.URL);

        ModelAndView mav = new ModelAndView();
        mav.setViewName("rssViewer");

        mav.addObject("feedItem", rssParser.getListItem());
        mav.addObject("feedChanel", rssParser.getMyChanel());
        return mav;
    }
}
