package com.luattv.rss.demo.rss;

import com.luattv.rss.demo.common.Constants;
import com.luattv.rss.demo.model.MyChanel;
import com.luattv.rss.demo.model.MyItem;
import com.rometools.rome.feed.rss.Channel;
import com.rometools.rome.feed.rss.Description;
import com.rometools.rome.feed.rss.Guid;
import com.rometools.rome.feed.rss.Item;
import org.springframework.web.servlet.view.feed.AbstractRssFeedView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by luattv on 14/06/2016.
 */
public class CreateRssView extends AbstractRssFeedView {



    @Override
    protected List<Item> buildFeedItems(Map<String, Object> map, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        @SuppressWarnings("unchecked")
        List<MyItem> myListItem = (List<MyItem>) map.get("feedItem");

        List<Item> items = new ArrayList<Item>(myListItem.size());
        for (MyItem myItem : myListItem) {
            Item item = new Item();
            item.setTitle(myItem.getTitle());
            item.setLink(myItem.getLink());

            Description description = new Description();
            description.setValue(myItem.getDescription());

            description.setType("text/html");
            item.setDescription(description);
            item.setPubDate(myItem.getPubDate());

            Guid guid = new Guid();
            guid.setValue(myItem.getGuid());
            guid.setPermaLink(false);
            item.setGuid(guid);

            // Add to list
            items.add(item);
        }
        return items;
    }

    @Override
    protected void buildFeedMetadata(Map<String, Object> model, Channel channel,
                                     HttpServletRequest request) {
        MyChanel myChanel = (MyChanel)model.get("feedChanel");


        channel.setTitle(myChanel.getTitle());
        channel.setLink(myChanel.getLink());
        channel.setDescription(myChanel.getDescription());
        channel.setLastBuildDate(myChanel.getLastBuildDate());
        channel.setDocs(Constants.DOCS);
        channel.setGenerator(Constants.GENERATOR);
        super.buildFeedMetadata(model, channel, request);
    }


}
