package com.luattv.rss.demo.service;


import com.luattv.rss.demo.common.Constants;
import com.luattv.rss.demo.model.MyChanel;
import com.luattv.rss.demo.model.MyItem;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by luattv on 14/06/2016.
 */
@Service
public class RssParser {


    private List<MyItem> listItem = new ArrayList<MyItem>();
    private MyChanel myChanel = new MyChanel();

    public RssParser() {

    }

    public void readRss(final String url) {
        try {
            XmlReader xmlReader = new XmlReader(new URL(url));
            SyndFeedInput input = new SyndFeedInput();
            SyndFeed feed = input.build(xmlReader);
            setMyChanel(feed, myChanel);

            for (Object o : feed.getEntries()) {
                MyItem myItem = new MyItem();
                SyndEntry entry = (SyndEntry) o;
                setMyItem(myItem, entry, listItem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (FeedException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setMyItem(MyItem myItem, SyndEntry entry, List<MyItem> listItem) {
        myItem.setTitle(excludeWord(entry.getTitle(), Constants.WORD));
        myItem.setPubDate(entry.getPublishedDate());
        myItem.setLink(excludeWord(entry.getLink(), Constants.WORD));
        myItem.setGuid(excludeWord(entry.getUri(), Constants.WORD));
        myItem.setDescription(excludeWord(entry.getDescription().getValue(), Constants.WORD));
        listItem.add(myItem);
    }

    private String excludeWord(String input, String word) {
        return input.replaceAll("(?i)" + word, "");
    }

    private void setMyChanel(SyndFeed feed, MyChanel myChanel) {
        myChanel.setDescription(feed.getDescription());
        myChanel.setTitle(feed.getTitle());
        myChanel.setLink(feed.getLink());
        myChanel.setLastBuildDate(feed.getPublishedDate());
    }

    public List<MyItem> getListItem() {
        return listItem;
    }

    public MyChanel getMyChanel() {
        return myChanel;
    }
}
