package com.luattv.rss.demo.model;

import java.util.Date;

/**
 * Created by luattv on 14/06/2016.
 */

public class MyChanel {

    private String title;

    private String link;

    private String description;

    private Date lastBuildDate;


    public MyChanel() {
    }

    public MyChanel(String title, String link, String description, Date lastBuildDate, String docs, String generator) {
        this.title = title;
        this.link = link;
        this.description = description;
        this.lastBuildDate = lastBuildDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getLastBuildDate() {
        return lastBuildDate;
    }

    public void setLastBuildDate(Date lastBuildDate) {
        this.lastBuildDate = lastBuildDate;
    }


}
