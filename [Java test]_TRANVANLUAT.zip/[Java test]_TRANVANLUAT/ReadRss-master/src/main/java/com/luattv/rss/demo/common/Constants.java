package com.luattv.rss.demo.common;

/**
 * Created by luattv on 14/06/2016.
 */
public class Constants {
    public final static String URL = "http://tech.uzabase.com/rss";
    public final static String WORD = "NewsPicks";
    public final static String DOCS = "http://blogs.law.harvard.edu/tech/rss";
    public final static String GENERATOR = "Hatena::Blog";
}
